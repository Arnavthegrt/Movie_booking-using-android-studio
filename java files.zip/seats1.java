package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class seats1 extends AppCompatActivity {

    GridView gridView;
    String[] seatNumbers = new String[16];
    TextView selectedSeatCount, totalPrice;
    Button submitButton;
    DatabaseReference seatsRef;
    String movieName, selectedTime;
    List<Integer> selectedSeatsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.custom_adapter);

        gridView = findViewById(R.id.gridView);
        selectedSeatCount = findViewById(R.id.selectedSeatCount);
        totalPrice = findViewById(R.id.totalPrice);
        submitButton = findViewById(R.id.submitButton);

        seatsRef = FirebaseDatabase.getInstance().getReference("seats1");

        movieName = getIntent().getStringExtra("MOVIE_NAME");
        selectedTime = getIntent().getStringExtra("SELECTED_TIME");

        for (int i = 0; i < 16; i++) {
            seatNumbers[i] = String.valueOf(i + 1);
        }

        CustomAdapter customAdapter = new CustomAdapter(this, seatNumbers, selectedSeatCount, totalPrice);
        gridView.setAdapter(customAdapter);

        submitButton.setEnabled(false);

        customAdapter.setOnSeatSelectionListener(() -> {
            selectedSeatsList.clear();
            selectedSeatsList.addAll(customAdapter.getSelectedSeats());
            submitButton.setEnabled(!selectedSeatsList.isEmpty());
        });

        submitButton.setOnClickListener(v -> {
            // Calculate selected seats
            StringBuilder selectedSeatsString = new StringBuilder();
            for (int position : selectedSeatsList) {
                String seatNumber = seatNumbers[position];
                seatsRef.child(seatNumber).child("isBooked").setValue(true);
                selectedSeatsString.append(seatNumber).append(", ");
            }

            if (selectedSeatsString.length() > 0) {
                selectedSeatsString.setLength(selectedSeatsString.length() - 2);
            }

            // Pass only the price to Payment activity
            Intent intent = new Intent(seats1.this, Payment.class);
            intent.putExtra("TOTAL_PRICE", totalPrice.getText().toString());
            intent.putExtra("MOVIE_NAME", movieName);
            intent.putExtra("SELECTED_TIME", selectedTime);
            intent.putExtra("SELECTED_SEATS", selectedSeatsString.toString());
            startActivity(intent);
        });
    }
}
