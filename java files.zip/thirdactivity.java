package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class thirdactivity extends AppCompatActivity {

    private Button btnHindi, btnEnglish, btnMarathi, btnGujarati;
    private TextView tvStepper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third); // Link to your XML file

        // Initialize buttons
        btnHindi = findViewById(R.id.btn_hindi);
        btnEnglish = findViewById(R.id.btn_english);




        // Set onClick listeners for each language button
        btnHindi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Example of redirecting to the next activity
                Intent intent = new Intent(thirdactivity.this, selection.class); // Replace with actual next activity
                startActivity(intent);
            }
        });

        btnEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // You can add an intent here to move to the next screen
                Intent intent = new Intent(thirdactivity.this, selectioneng.class); // Replace with actual next activity
                startActivity(intent);
            }
        });
//
//        btnMarathi.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(thirdactivity.this, "Marathi selected", Toast.LENGTH_SHORT).show();
//                // Example of redirecting to the next activity
//                Intent intent = new Intent(thirdactivity.this, NextActivity.class); // Replace with actual next activity
//                startActivity(intent);
//            }
//        });
//
//        btnGujarati.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(thirdactivity.this, "Gujarati selected", Toast.LENGTH_SHORT).show();
//                // Example of redirecting to the next activity
//                Intent intent = new Intent(thirdactivity.this, NextActivity.class); // Replace with actual next activity
//                startActivity(intent);
//            }
//        });
    }
}
