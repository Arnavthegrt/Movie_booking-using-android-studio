package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Payment extends AppCompatActivity {

    private TextView paymentEditText;
    private Button confirmPaymentButton;
    private String totalPrice, movieName, selectedTime, selectedSeats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.payment);

        paymentEditText = findViewById(R.id.payment);
        confirmPaymentButton = findViewById(R.id.sub);

        // Retrieve values passed from seat activity
        totalPrice = getIntent().getStringExtra("TOTAL_PRICE");
        movieName = getIntent().getStringExtra("MOVIE_NAME");
        selectedTime = getIntent().getStringExtra("SELECTED_TIME");
        selectedSeats = getIntent().getStringExtra("SELECTED_SEATS");

        // Display the total price
        paymentEditText.setText("Rupees: " + totalPrice);

        confirmPaymentButton.setOnClickListener(v -> {
            // After payment is confirmed, pass all the data to FinalDetailsActivity
            Intent finalIntent = new Intent(Payment.this, FinalDetailsActivity.class);
            finalIntent.putExtra("MOVIE_NAME", movieName);
            finalIntent.putExtra("SELECTED_TIME", selectedTime);
            finalIntent.putExtra("TOTAL_PRICE", totalPrice);
            finalIntent.putExtra("SELECTED_SEATS", "Seats - " + selectedSeats);
            startActivity(finalIntent);
        });
    }
}
