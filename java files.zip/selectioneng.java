package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class selectioneng extends AppCompatActivity { // Rename class to follow naming conventions

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selection_eng); // Ensure this layout file name matches your XML file

        // Define buttons based on IDs in your layout
        Button heraPheriButton = findViewById(R.id.herapheri);
        Button jawanButton = findViewById(R.id.jawan);
        Button znmdButton = findViewById(R.id.znmd);
        Button bhulButton = findViewById(R.id.bhul);

        // Attach click listeners to each button to start SelectTimeActivity with the movie name
        heraPheriButton.setOnClickListener(v -> openSelectTimeActivity("IronMan"));
        jawanButton.setOnClickListener(v -> openSelectTimeActivity("Rampage"));
        znmdButton.setOnClickListener(v -> openSelectTimeActivity("Venom"));
        bhulButton.setOnClickListener(v -> openSelectTimeActivity("Jumanji"));
    }

    // Helper method to start SelectTimeActivity and pass the selected movie name as extra data
    private void openSelectTimeActivity(String movieName) {
        Intent intent = new Intent(selectioneng.this, SelectTimeActivity.class);
        intent.putExtra("MOVIE_NAME", movieName); // Pass the selected movie name to SelectTimeActivity
        startActivity(intent);
    }
}
