package com.example.moviebooking;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SelectTimeActivity extends AppCompatActivity {

    private String selectedTime = null; // Variable to store the selected time
    private Button lastSelectedButton = null; // Variable to store the last selected button for color reset

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_time);

        // Retrieve the selected movie name from the Intent
        String movieName = getIntent().getStringExtra("MOVIE_NAME");

        // Find the TextView and update it to show "Sunday - [Movie Name]"
        TextView dayAndMovieTextView = findViewById(R.id.fixedDay);
        if (movieName != null) {
            dayAndMovieTextView.setText("Sunday - " + movieName);
        }

        // Set up time selection buttons with their click listeners
        setupTimeButton(R.id.time_10am, "10:00 AM", movieName);
        setupTimeButton(R.id.time_12pm, "12:00 PM", movieName);
        setupTimeButton(R.id.time_2pm, "2:00 PM", movieName);
        setupTimeButton(R.id.time_4pm, "4:00 PM", movieName);
        setupTimeButton(R.id.time_6pm, "6:00 PM", movieName);
        setupTimeButton(R.id.time_8pm, "8:00 PM", movieName);
    }

    // Helper method to set up time selection buttons
    private void setupTimeButton(int buttonId, final String time, final String movieName) {
        Button timeButton = findViewById(buttonId);
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reset the color of the previously selected button, if any
                if (lastSelectedButton != null) {
                    lastSelectedButton.setBackgroundColor(Color.parseColor("#5C6BC0")); // Reset to default color
                }

                // Change the color of the current selected button to a darker shade
                timeButton.setBackgroundColor(Color.parseColor("#001A66")); // Darker highlight color
                lastSelectedButton = timeButton; // Update the last selected button

                selectedTime = time; // Store the selected time

                // Directly navigate to the seat selection activity with the selected time and movie name
                Intent intent = new Intent(SelectTimeActivity.this, seat.class);
                intent.putExtra("SELECTED_TIME", selectedTime);
                intent.putExtra("MOVIE_NAME", movieName);
                startActivity(intent);
            }
        });
    }
}
