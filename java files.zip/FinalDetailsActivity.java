package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FinalDetailsActivity extends AppCompatActivity {

    private String movieName;
    private String selectedTime;
    private String seatNumbers;
    private String totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_details);

        // Retrieve data from Intent
        movieName = getIntent().getStringExtra("MOVIE_NAME");
        selectedTime = getIntent().getStringExtra("SELECTED_TIME");
        seatNumbers = getIntent().getStringExtra("SELECTED_SEATS");
        totalPrice = getIntent().getStringExtra("TOTAL_PRICE");

        // Find views by ID
        ImageView posterImageView = findViewById(R.id.posterImageView);
        TextView movieNameTextView = findViewById(R.id.movieNameTextView);
        TextView timeTextView = findViewById(R.id.timeTextView);
        TextView seatsTextView = findViewById(R.id.seatsTextView);
        TextView totalAmountTextView = findViewById(R.id.totalAmountTextView);
        Button emailButton = findViewById(R.id.emailButton);

        // Set the TextView content
        movieNameTextView.setText(movieName);
        timeTextView.setText("Time: " + selectedTime);
        seatsTextView.setText(seatNumbers);
        totalAmountTextView.setText(totalPrice);

        // Set the movie poster image based on movie name
        setMoviePoster(movieName, posterImageView);

        // Set up the email button to send booking details
        emailButton.setOnClickListener(v -> sendEmailWithBookingDetails());
    }

    private void setMoviePoster(String movieName, ImageView posterImageView) {
        Log.d("FinalDetailsActivity", "Setting poster for movie: " + movieName);

        if ("Hera Pheri".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_1);
        } else if ("Jawan".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_3);
        } else if ("ZNMD".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_2);
        } else if ("Bhool Bhulaiyaa".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_4);
        } else if ("IronMan".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_5);
        } else if ("Rampage".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_6);
        } else if ("Venom".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_7);
        } else if ("Jumanji".equals(movieName)) {
            posterImageView.setImageResource(R.drawable.img_8);
        }
    }

    private void sendEmailWithBookingDetails() {
        String subject = "Your Movie Booking Details";
        String message = "Thank you for booking with us!\n\n"
                + "Movie: " + movieName + "\n"
                + "Time: " + selectedTime + "\n"
                + "Seats: " + seatNumbers + "\n"
                + "Total Price: " + totalPrice + "\n\n"
                + "We look forward to seeing you at the show!";

        // Intent to send email
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");  // Set MIME type for email
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"user@example.com"});  // Replace with actual user email
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);

        // Start email activity if available
        if (emailIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(emailIntent, "Send email using..."));
        } else {
            Log.d("FinalDetailsActivity", "No email app available");
        }
    }
}
