package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SecondActivity extends AppCompatActivity {

    private EditText etName, etPhone, etEmail, etPassword;
    private Button btnSubmit;
    DatabaseReference reference;
    TextView loginRedirect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second); // Linking to the XML layout file

        // Initialize Firebase
        FirebaseApp.initializeApp(this);

        // Initialize views
        etName = findViewById(R.id.et_username);
        loginRedirect = findViewById(R.id.textView);
        etEmail = findViewById(R.id.et_email);
        etPassword = findViewById(R.id.et_password);
        btnSubmit = findViewById(R.id.btn_submitt);

        // Set up onClickListener for the Submit button
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get text from EditText fields
                String name = etName.getText().toString().trim();
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Validate inputs
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(SecondActivity.this, "Please enter your name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(email)) {
                    Toast.makeText(SecondActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();
                } else if (!isValidEmail(email)) {
                    Toast.makeText(SecondActivity.this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
                } else {
                    // Initialize Firebase database
                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    reference = database.getReference("users");

                    // Create a HelperClass object and push it to the database
                    HelperClass helperClass = new HelperClass(password, email, name);
                    reference.child(name).setValue(helperClass);

                    // Show a success message and redirect to Login activity
                    Toast.makeText(SecondActivity.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(SecondActivity.this, Login.class);
                    startActivity(intent);
                }
            }
        });


        loginRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SecondActivity.this, Login.class);
                startActivity(i);
            }
        });
    }


    private boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }


    private boolean isValidPhone(String phone) {
        return phone.length() == 10 && TextUtils.isDigitsOnly(phone);
    }
}
