package com.example.moviebooking;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.selection);

        // Define buttons based on IDs in your layout
        Button heraPheriButton = findViewById(R.id.herapheri);
        Button jawanButton = findViewById(R.id.jawan);
        Button znmdButton = findViewById(R.id.znmd);
        Button bhulButton = findViewById(R.id.bhul);

        // Attach click listeners to each button to start SelectTimeActivity with the movie name
        heraPheriButton.setOnClickListener(v -> openSelectTimeActivity("Hera Pheri"));
        jawanButton.setOnClickListener(v -> openSelectTimeActivity("Jawan"));
        znmdButton.setOnClickListener(v -> openSelectTimeActivity("ZNMD"));
        bhulButton.setOnClickListener(v -> openSelectTimeActivity("Bhool Bhulaiyaa"));
    }

    // Helper method to start SelectTimeActivity and pass the selected movie name as extra data
    private void openSelectTimeActivity(String movieName) {
        Intent intent = new Intent(selection.this, SelectTimeActivity.class);
        intent.putExtra("MOVIE_NAME", movieName);
        startActivity(intent);
    }
}
