package com.example.moviebooking;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class Login extends AppCompatActivity {

    Button btnCheck;
    EditText username,password;
    TextView redirect;
    @SuppressLint({"MissingInflatedId", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btnCheck = findViewById(R.id.btn_submit);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        redirect = findViewById(R.id.redirect);

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!validatePassword() | !validateUsername()){

                }else{
                    checkUser();
                }
            }
        });

        redirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this, SecondActivity.class);
                startActivity(intent);
            }
        });
    }

    public boolean validateUsername(){
        String val = username.getText().toString();
        if(val.isEmpty()){
            username.setError("Username cannot be empty");
            return false;
        }
        else {
            username.setError(null);
            return true;
        }
    }

    public boolean validatePassword(){
        String val = password.getText().toString();
        if(val.isEmpty()){
            password.setError("Password cannot be empty");
            return false;
        }
        else {
            password.setError(null);
            return true;
        }
    }

    public void checkUser() {
        String userUsername = username.getText().toString().trim();
        String userPassword = password.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users");

        // Query to find the user by their username
        Query checkUserDatabase = reference.orderByChild("username").equalTo(userUsername);

        checkUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Clear any previous username errors
                    username.setError(null);

                    // Retrieve the password stored in Firebase
                    for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                        String passwordFromDB = userSnapshot.child("password").getValue(String.class);

                        // Compare the entered password with the one from the database
                        if (Objects.equals(passwordFromDB, userPassword)) {
                            Intent intent = new Intent(Login.this, thirdactivity.class);
                            startActivity(intent);
                        } else {
                            password.setError("Invalid Credentials");
                            password.requestFocus();
                        }
                    }
                } else {
                    // If username doesn't exist
                    username.setError("User does not exist");
                    username.requestFocus();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

}




