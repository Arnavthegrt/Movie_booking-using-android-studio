package com.example.moviebooking;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashSet;
import java.util.Set;

public class CustomAdapter extends BaseAdapter {
    private Context context;
    private String[] seatNumbers;
    private Set<Integer> selectedSeats = new HashSet<>();
    private TextView selectedSeatCount;
    private TextView totalPrice;
    private static final int SEAT_PRICE = 200;

    // Firebase Database reference
    private DatabaseReference seatsRef;
    private OnSeatSelectionListener seatSelectionListener;  // Callback listener for seat selection

    public CustomAdapter(Context context, String[] seatNumbers, TextView selectedSeatCount, TextView totalPrice) {
        this.context = context;
        this.seatNumbers = seatNumbers;
        this.selectedSeatCount = selectedSeatCount;
        this.totalPrice = totalPrice;

        // Initialize Firebase reference for the seats collection
        this.seatsRef = FirebaseDatabase.getInstance().getReference("seats");
    }

    // Define interface for seat selection callback
    public interface OnSeatSelectionListener {
        void onSeatSelectionChanged();
    }

    // Setter for the listener
    public void setOnSeatSelectionListener(OnSeatSelectionListener listener) {
        this.seatSelectionListener = listener;
    }

    @Override
    public int getCount() {
        return seatNumbers.length;
    }

    @Override
    public Object getItem(int position) {
        return seatNumbers[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.seat_item, parent, false);

            holder = new ViewHolder();
            holder.seatButton = convertView.findViewById(R.id.seat_button);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        String seatNumber = seatNumbers[position];
        holder.seatButton.setText(seatNumber);

        seatsRef.child(seatNumber).child("isBooked").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                Boolean isBooked = snapshot.getValue(Boolean.class);

                if (Boolean.TRUE.equals(isBooked)) {
                    // Disable the button if seat is booked
                    holder.seatButton.setEnabled(false);
                    holder.seatButton.setBackgroundColor(Color.GRAY);  // Optional: Change color to indicate booked
                } else {
                    // Enable seat selection for available seats
                    holder.seatButton.setEnabled(true);
                    holder.seatButton.setOnClickListener(v -> {
                        if (selectedSeats.contains(position)) {
                            selectedSeats.remove(position);
                            holder.seatButton.setBackgroundResource(R.drawable.seat_button);
                        } else {
                            selectedSeats.add(position);
                            holder.seatButton.setBackgroundColor(0xFF4CAF50);  // Mark as selected
                        }
                        updateSelectedSeatCount();

                        // Notify the listener of seat selection changes
                        if (seatSelectionListener != null) {
                            seatSelectionListener.onSeatSelectionChanged();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Handle database error
            }
        });

        return convertView;
    }

    private void updateSelectedSeatCount() {
        int selectedCount = selectedSeats.size();
        selectedSeatCount.setText("Selected Seats: " + selectedCount);
        totalPrice.setText("Total Price: ₹" + (selectedCount * SEAT_PRICE));
    }

    public Set<Integer> getSelectedSeats() {
        return selectedSeats;
    }

    private static class ViewHolder {
        Button seatButton;
    }
}
